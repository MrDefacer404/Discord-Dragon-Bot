# Ticket-Bot
A discord ticket bot

Setup:

Make a new channel with whatever permissions you want just make sure the bot can see the channel but call the channel reports and make a second one called logs
M
Change settings in the config file.

Dependancies 
npm install ms -S
npm install nodemon
